"""

@author: QuantInsti
Webpage: https://www.quantinsti.com/

############################# DISCLAIMER #############################
This file is a template only and should not be
used for live trading without appropriate backtesting and tweaking of
the strategy parameters.
######################################################################

File: The trading app file

Copyright 2023 QuantInsti Quantitative Learnings Pvt Ltd. 
Licensed under the Apache License, Version 2.0 (the "License"). 
You may not use this file except in compliance with the License. 
You may obtain a copy of the License at  
http://www.apache.org/licenses/LICENSE-2.0 
Unless required by applicable law or agreed to in writing, software # distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

"""

# Import necessary libraries
import os
import yfinance as yf
from ibapi.client import EClient
from ibapi.wrapper import EWrapper
from threading import Thread
import pandas as pd
import numpy as np
import datetime as dt
import logging
from trading_app_files import trading_app_functions as taf
import strategy_file as sf
import time
from threading import Event
from concurrent.futures import ThreadPoolExecutor
import smtplib
from trading_app_files import trading_app_for_download_data as tadd 
from trading_app_files import trading_app_epat_create_database as tacd

now_ = dt.datetime.now()

# Set the month string to save the log file
if now_.month < 10:
    month = '0'+str(now_.month)
else:
    month = now_.month
# Set the day string to save the log file
if now_.day < 10:
    day = '0'+str(now_.day)
else:
    day = now_.day
# Set the hour string to save the log file
if now_.hour < 10:
    hour = '0'+str(now_.hour)
else:
    hour = now_.hour
# Set the minute string to save the log file
if now_.minute < 10:
    minute = '0'+str(now_.minute)
else:
    minute = now_.minute
# Set the second string to save the log file
if now_.second < 10:
    second = '0'+str(now_.second)
else:
    second = now_.second

# Save all the trading app info in the following log file
logging.basicConfig(filename=f'trading_app_files/log_files/log_file_{now_.year}_{month}_{day}_{hour}_{minute}_{second}.log',
                    level=logging.DEBUG,
                    format='%(asctime)s.%(msecs)03d %(levelname)s %(module)s - %(funcName)s: %(message)s', datefmt='%Y-%m-%d %H:%M:%S')

# Define trading app class - inherits from EClient and EWrapper
class trading_app(EClient, EWrapper):
    
    # Initialize the class - and inherited classes
    def __init__(self, account, account_currency, symbol, timezone, data_frequency, historical_data_address, base_df_address, leverage, risk_management_target, stop_loss_multiplier, take_profit_multiplier, 
                 purged_window_size, embargo_period, market_open_time, market_close_time, 
                 previous_day_start_datetime, trading_day_end_datetime, day_end_datetime, current_period, previous_period, next_period, train_span, test_span, max_window):
        
        # Initialize the class from parents
        EClient.__init__(self, self)
        
        # Start time to get later the number of seconds used to run the whole strategy per period
        self.app_start_time = dt.datetime.now()
        
        # The account's base currency
        self.account_currency = account_currency
        
        # Set the account string depending on whether we're using a paper or real account
        if self.port == 4796 or self.port == 4001:
            self.account = 'account'
        else:
            # Paper trading account string
            self.account = account
            
        # Set the data frequency        
        self.data_frequency = data_frequency
        # Set the historical data file address
        self.historical_data_address = historical_data_address
        # Set the base_df file address
        self.base_df_address = base_df_address
        # Set the time zone of the trader 
        self.zone = timezone
        
        # Set the market open datetime of the current week
        self.market_open_time = market_open_time
        # Set the market close datetime of the current week
        self.market_close_time = market_close_time
        # Set the previous day start datetime 
        self.previous_day_start_datetime = previous_day_start_datetime
        # Set the trading day end datetime
        self.trading_day_end_datetime = trading_day_end_datetime
        # Set the day-end datetime
        self.day_end_datetime = day_end_datetime
        # Set the current period to trade
        self.current_period = current_period
        # Set the previous period we traded
        self.previous_period = previous_period
        # Set the next period we'll trade
        self.next_period = next_period
        # Set the train span to be used to create the base_df
        self.train_span = train_span
        # Set the test span for the trading app
        self.test_span = test_span
        # Set the maximum window to compute the technical indicators
        self.max_window = max_window
        # Set the purged window size to create the base_df
        self.purged_window_size = purged_window_size
        # Set the embargo period to create the base_df
        self.embargo_period = embargo_period
        
        # Get the data frequency number and time string from the data_frequency string
        self.frequency_number, self.frequency_string = taf.get_data_frequency_values(data_frequency)
        
        # Call the trading app database
        database = pd.ExcelFile('trading_app_files/epat_trading_app_database.xlsx')
        # Load the open orders dataframe
        self.open_orders = pd.read_excel(database, "open_orders", index_col = 0)
        # Load the orders status dataframe
        self.orders_status = pd.read_excel(database, "orders_status", index_col = 0)
        # Load the executions dataframe
        self.exec_df = pd.read_excel(database, "executions", index_col = 0)
        # Load the commissions dataframe
        self.comm_df = pd.read_excel(database, "commissions", index_col = 0)
        # Load the positions dataframe
        self.pos_df = pd.read_excel(database, "positions", index_col = 0)
        # Load the cash balance dataframe
        self.cash_balance = database.parse("cash_balance", index_col = 0)

        # Convert to datetime the string index of each of the previous dataframes
        self.open_orders.index = pd.to_datetime(self.open_orders.index)
        self.orders_status.index = pd.to_datetime(self.orders_status.index)
        self.exec_df.index = pd.to_datetime(self.exec_df.index)
        self.comm_df.index = pd.to_datetime(self.comm_df.index)
        self.pos_df.index = pd.to_datetime(self.pos_df.index)
        self.cash_balance.index = pd.to_datetime(self.cash_balance.index)

        # Kiad the app time spent dataframe
        self.app_time_spent = database.parse("app_time_spent", index_col=0)
        # Convert to float previous_time_spent seconds column
        self.previous_time_spent = float(self.app_time_spent['seconds'].iloc[0])        

        # Load the periods traded dataframe
        self.periods_traded = database.parse("periods_traded", index_col = 0)
        
        # Convert to datetime type the trade_time column of the previous_traded dataframe
        self.periods_traded['trade_time'] = pd.to_datetime(self.periods_traded['trade_time'])
        
        # Add a new row to the periods_traded column with the current period
        self.periods_traded.loc[len(self.periods_traded.index),:] = [current_period, 0, market_open_time, market_close_time]
        
        # Create the new_df dataframe to save the downloaded historical BID and ASK data
        self.new_df = {}
        self.new_df['0'] = pd.DataFrame()
        self.new_df['1'] = pd.DataFrame()
       
        # Set the ticker
        self.ticker = symbol
        
        # Import the historical data 
        self.historical_data = pd.read_csv(historical_data_address, index_col=0)
        # Convert the historical data index to datetime
        self.historical_data.index = pd.to_datetime(self.historical_data.index)
        
        # Use the last train_span observations for the historical data
        self.historical_data = self.historical_data.tail(self.train_span)
                
        # Create the forex contract based on the ticker
        self.contract = taf.ForexContract(self.ticker)
        
        # Create a dictionary to save the app output errors
        self.errors_dict = {}
        
        # Set the risk management target return
        self.risk_management_target = risk_management_target
        # Set the stop loss multiplier
        self.stop_loss_multiplier = stop_loss_multiplier
        # Set the stop loss multiplier
        self.take_profit_multiplier = take_profit_multiplier
        # Set the leverage to be used to trade
        self.leverage = leverage
        
        # Load the optimal features dataframe
        features_df = pd.read_excel('trading_app_files/optimal_features_df.xlsx', index_col=0)
        # Set the scalable features to prepare the data
        self.scalable_features = features_df['scalable_features'].dropna().tolist()
        # Set all the features to prepare the data
        self.final_input_features = features_df['final_features'].dropna().tolist()
        # Set the stop loss order id to NaN             
        self.sl_order_id = np.nan
        # Set the take profit order id to NaN             
        self.tp_order_id = np.nan
        
        # Set the count values to zero to stop the app in case there's no way to keep the app running smoothly
        self.count = 0
        self.last_value_count = 0
        
        # Create the account update information dataframe
        self.acc_update = pd.DataFrame()        
        # Create a dictionary to save the historical data events to download it properly        
        self.hist_data_events = {}
        # Set the historical data threading event for the BID and ASK data request
        self.hist_data_events['0'] = Event()
        self.hist_data_events['1'] = Event()
        # Set a threading event to request the open orders and orders status
        self.orders_request_event = Event()
        # Set a threading event to request the trading positions
        self.positions_request_event = Event()
        # Set the threading event for the account update
        self.account_update_event = Event()
        # Set the threading event for the executions request
        self.executions_request_event = Event()

        # Create temporary dataframes to be used while requesting previous trading information
        self.acc_update = pd.DataFrame()
        self.temp_open_orders = pd.DataFrame()
        self.temp_orders_status = pd.DataFrame()
        self.temp_exec_df = pd.DataFrame()
        self.temp_comm_df = pd.DataFrame()  
        self.temp_pos_df = pd.DataFrame() 
        
        # Set the strategy end to False
        self.strategy_end = False
        
    def error(self, reqId, code, msg, advancedOrderRejectJson=''):
        ''' Called if an error occurs '''
        self.errors_dict[code] = msg
        print('Error: {} - {} - {}'.format(reqId, code, msg))
        logging.info('Error: {} - {} - {}'.format(reqId, code, msg))

    def connection_monitor(self):
        ''' Check continuously if there's a need to disconnect the app '''

        while True:
            # If the app is disconnected
            if not self.isConnected():
                print("Not connected. Breaking loop...")
                logging.info("Not connected. Breaking loop.")
                self.stop()
                break
            # If the app is disconnected based on the errors' dictionary
            if (502 in list(self.errors_dict.keys())):
                print("Not connected. Breaking loop...")
                logging.info("Not connected. Breaking loop.")
                self.stop()
                break
            if self.last_value_count >= 50:
                print("count got to 50. Let's disconnect...")
                print("Not connected. Breaking loop.")
                logging.info("Not connected. Breaking loop.")
                self.stop()
                break
            # If the strategy was finished correctly
            if self.strategy_end == True:
                print("Strategy is done. Let's disconnect...")
                logging.info("Strategy is done. Let's disconnect...")
                self.stop()
                break      
            if (1100 in list(self.errors_dict.keys())):
                print("Not connected. Breaking loop...")
                logging.info("Not connected. Breaking loop.")
                self.stop()
                break
                
    def nextValidId(self, orderId):
        ''' Set the next order id '''
        # If the app is connected
        if self.isConnected():
            super().nextValidId(orderId)
            self.nextValidOrderId = orderId
            print("NextValidId:", orderId)
            logging.info("NextValidId: {}".format(orderId))
            time.sleep(1)
        else:
            return
    
    def openOrder(self, orderId, contract, order, orderState):
        ''' Function to call the open orders '''
        super().openOrder(orderId, contract, order, orderState)
        # Create a dictionary to save the data
        dictionary = {"PermId":order.permId, \
                      "ClientId": order.clientId, \
                      "OrderId": orderId, 
                      "Account": order.account, \
                      "Symbol": contract.symbol, \
                      "SecType": contract.secType,
                      "Exchange": contract.exchange, \
                      "Action": order.action, \
                      "OrderType": order.orderType,
                      "TotalQty": float(order.totalQuantity), \
                      "CashQty": order.cashQty, 
                      "LmtPrice": order.lmtPrice, \
                      "AuxPrice": order.auxPrice,\
                      "Status": orderState.status,\
                      "datetime":dt.datetime.now().replace(microsecond=0)}
        # Save the data into the temporary dataframe
        self.temp_open_orders = pd.concat([self.temp_open_orders, pd.DataFrame(dictionary, index=[0])], ignore_index=True)

        
    def orderStatus(self, orderId, status, filled, remaining, avgFillPrice, \
                    permId, parentId, lastFillPrice, clientId, whyHeld, \
                    mktCapPrice):
        ''' Function to call the orders status'''
        super().orderStatus(orderId, status, filled, remaining, \
                            avgFillPrice, permId, parentId, lastFillPrice, \
                            clientId, whyHeld, mktCapPrice)
        
        # Create a dictionary to save the data
        dictionary = {"OrderId": orderId, \
                      "Status":status, \
                      "Filled":filled, \
                      "PermId":permId, \
                      "ClientId": clientId, \
                      "Remaining": float(remaining), \
                      "AvgFillPrice": avgFillPrice, \
                      "LastFillPrice": lastFillPrice, \
                      "datetime":dt.datetime.now().replace(microsecond=0)}
        # Save the data into the temporary dataframe
        self.temp_orders_status = pd.concat([self.temp_orders_status, pd.DataFrame(dictionary, index=[0])], ignore_index=True)
        
    def request_orders(self):
        ''' Function to request the open orders and orders status'''
        print('Requesting open positions and orders status...')
        logging.info('Requesting open positions and orders status...')
        
        # If the app is connected
        if self.isConnected():
            # Clear the threading event
            self.orders_request_event.clear()
            # Request the open orders and orders status
            self.reqOpenOrders()
            # Make the event end when the request is done
            self.orders_request_event.wait()
        else:
            return
        
        # If the temporary open orders dataframe is not empty
        if (self.temp_open_orders.empty == False):
            # Set the datetime column as index
            self.temp_open_orders.set_index('datetime',inplace=True)
            # Erase the index name
            self.temp_open_orders.index.name = ''
            # Concatenate the temporary dataframe with the whole corresponding dataframe
            self.open_orders = pd.concat([self.open_orders,self.temp_open_orders])
            # Drop row duplicates
            self.open_orders.drop_duplicates(inplace=True)
            # Sort the whole dataframe by index
            self.open_orders.sort_index(ascending=True, inplace=True)
            # Clear the temporary dataframe
            self.temp_open_orders = pd.DataFrame()

        # If the temporary orders status dataframe is not empty
        if (self.temp_orders_status.empty == False):
            # Set the datetime column as index
            self.temp_orders_status.set_index('datetime',inplace=True)
            # Erase the index name
            self.temp_orders_status.index.name = ''
            # Concatenate the temporary dataframe with the whole corresponding dataframe
            self.orders_status = pd.concat([self.orders_status,self.temp_orders_status])
            # Drop row duplicates            
            self.orders_status.drop_duplicates(inplace=True)
            # Sort the whole dataframe by index
            self.orders_status.sort_index(ascending=True, inplace=True)
            # Clear the temporary dataframe
            self.temp_orders_status = pd.DataFrame()

        print('Open positions and orders status successfully requested...')
        logging.info('Open positions and orders status successfully requested...')
        
    def openOrderEnd(self):
        print("Open orders request was successfully completed")
        self.orders_request_event.set()

    # Receive details when orders are executed        
    def execDetails(self, reqId: int, contract, execution):
        ''' Function to call the trading executions'''
        print('Requesting the trading executions...')
        logging.info('Requesting the trading executions...')
        
        super().execDetails(reqId, contract, execution)
        # Create a dictionary to save the data
        dictionary = {"OrderId": execution.orderId,  
                      "PermId":execution.permId, \
                      "ExecutionId":execution.execId, \
                      "Symbol": contract.symbol, \
                      "Side":execution.side, \
                      "Price":execution.price, \
                      "AvPrice":execution.avgPrice, \
                      "cumQty":execution.cumQty, \
                      "Currency":contract.currency, \
                      "SecType": contract.secType, \
                      "Position": float(execution.shares), \
                      "Execution Time": execution.time, \
                      "Last Liquidity": execution.lastLiquidity, \
                      "OrderRef":execution.orderRef, \
                      "datetime":dt.datetime.now().replace(microsecond=0)}
            
        # Save the data into the temporary dataframe
        self.temp_exec_df = pd.concat([self.temp_exec_df, pd.DataFrame(dictionary, index=[0])], ignore_index=True)
        
    def commissionReport(self, commissionReport):
        ''' Function to call the trading commissions'''
        print('Requesting the trading commissions...')
        logging.info('Requesting the trading commissions...')
        
        super().commissionReport(commissionReport)
        # Create a dictionary to save the data
        dictionary = {"ExecutionId":commissionReport.execId, \
                      "Commission": commissionReport.commission, \
                      "Currency":commissionReport.currency, \
                      "Realized PnL": float(commissionReport.realizedPNL), \
                      "datetime":dt.datetime.now().replace(microsecond=0)}
            
        # Save the data into the temporary dataframe
        self.temp_comm_df = pd.concat([self.temp_comm_df, pd.DataFrame(dictionary, index=[0])], ignore_index=True)

    def execDetailsEnd(self, reqId: int):
        super().execDetailsEnd(reqId)
        print("Trading executions request was successfully finished. ReqId:", reqId)
        self.executions_request_event.set()
                
    # Receive the positions from the TWS
    def position(self, account, contract, position, avgCost):
        ''' Function to call the trading positions'''
        print('Requesting the trading positions...')
        logging.info('Requesting the trading positions...')
        super().position(account, contract, position, avgCost)
        # Create a dictionary to save the data
        dictionary = {"Account":account, "Symbol": contract.symbol, \
                      "SecType": contract.secType,
                      "Currency": contract.currency, "Position": float(position), \
                      "Avg cost": avgCost, "datetime":dt.datetime.now().replace(microsecond=0)}
            
        # Save the data into the temporary dataframe
        self.temp_pos_df = pd.concat([self.temp_pos_df, pd.DataFrame(dictionary, index=[0])], ignore_index=True)
        
    # Display message once the positions are retrieved
    def positionEnd(self):
        print('Positions Retrieved.')
        self.positions_request_event.set()

    def request_positions(self):
        ''' Function to request the trading positions'''
        print('Requesting positions...')
        logging.info('Requesting positions...')
        
        # If the app is connected
        if self.isConnected():
            # Clear the threading event
            self.positions_request_event.clear()
            # Request the trading positions
            self.reqPositions()
            # Set the event to wait until the request is finished
            self.positions_request_event.wait()
        else:
            return
        
        # If the temporary positions dataframe is not empty
        if (self.temp_pos_df.empty == False):
            print('holaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa')
            pd.set_option('display.max_columns', None)
            print(self.temp_pos_df)
            # Set the datetime column as index
            self.temp_pos_df.set_index('datetime',inplace=True)
            # Erase the index name
            self.temp_pos_df.index.name = ''
            # Concatenate the temporary dataframe with the main dataframe
            self.pos_df = pd.concat([self.pos_df, self.temp_pos_df])
            # Drop duplicates
            self.pos_df.drop_duplicates(inplace=True)
            # Sort the positions dataframe by index
            self.pos_df.sort_index(ascending=True, inplace=True)
            # Clear the temporary dataframe
            self.temp_pos_df = pd.DataFrame()
        print('Open positions successfully requested...')
        logging.info('Open positions successfully requested...')
                
    # Receive historical bars from TWS
    def historicalData(self, reqId, bar):
        ''' Function to call the historical data'''
        # Save the data into the new_df dataframe
        self.new_df[f'{reqId}'].loc[bar.date,'close'] = bar.close
        self.new_df[f'{reqId}'].loc[bar.date,'open'] = bar.open
        self.new_df[f'{reqId}'].loc[bar.date,'high'] = bar.high
        self.new_df[f'{reqId}'].loc[bar.date,'low'] = bar.low
        
    def download_hist_data(self, params):
        """Function to download the historical data"""
        # Set the function inputs as per the params list
        hist_id, duration, candle_size, whatToShow = params[0], params[1], params[2], params[3]
        
        # If the app is connected
        if self.isConnected():
            # Clear the threading event
            self.hist_data_events[f'{hist_id}'].clear()
            
            # Downlod the data
            self.reqHistoricalData(reqId=hist_id, 
                                   contract=self.contract,
                                   endDateTime='',
                                   durationStr=duration,
                                   barSizeSetting=candle_size,
                                   whatToShow=whatToShow,
                                   useRTH=False,
                                   formatDate=1,
                                   keepUpToDate=False,
                                   # EClient function to request contract details
                                   chartOptions=[])	
            
            # Make the event wait until the download is finished
            self.hist_data_events[f'{hist_id}'].wait()
        else:
            # Return the function in case we couldn't download the data
            return
                
    # Display a message once historical data is retrieved
    def historicalDataEnd(self,reqId,start,end):
        super().historicalDataEnd(reqId,start,end)
        print("Historical Data Download finished...")
        logging.info("Historical Data Download finished...")
        # Set the event and end the historical data download
        self.hist_data_events[f'{reqId}'].set()

    def prepare_downloaded_data(self, params):
        print(f'preparing the {params[-1]} data...')
        logging.info(f'preparing {params[-1]} the data...')
        
        # Rename the downloaded historical data columns
        self.new_df[f'{params[0]}'].rename(columns={'open':f'{params[-1].lower()}_open','high':f'{params[-1].lower()}_high',\
                                                  'low':f'{params[-1].lower()}_low','close':f'{params[-1].lower()}_close'},inplace=True)
        
        # Set the index to datetime type            
        self.new_df[f'{params[0]}'].index = pd.to_datetime(self.new_df[f'{params[0]}'].index, format='%Y%m%d %H:%M:%S %Z')
        # Get rid of the timezone tag
        self.new_df[f'{params[0]}'].index = self.new_df[f'{params[0]}'].index.tz_localize(None)
        
        print(f'{params[-1]} data is prepared...')
        logging.info(f'{params[-1]} data is prepared...')
           
    def update_hist_data(self):
        ''' Request the historical data '''
        
        print("Requesting the historical data...")
        logging.info("Requesting the historical data...")
        
        # Set the number of days that have passed from the last historical data datetime up to the current period
        days_passed_number = ((self.current_period - self.historical_data.index[-1]) + dt.timedelta(days=1)).days
        # Set the days to be used to download the historical data
        days_passed = f'{days_passed_number if days_passed_number>0 else (days_passed_number+2)} D'
        
        # Set the params list to download the data
        params_list = [[0, days_passed, '1 min', 'BID'], [1, days_passed, '1 min', 'ASK']]
        
        # If the app is connected
        if self.isConnected():
            # Download the historical BID and ASK data
            with ThreadPoolExecutor(2) as executor:
                list(executor.map(self.download_hist_data, params_list)) 
        else:
            return

        # If the app is connected
        if self.isConnected():
            # Prepare the data
            with ThreadPoolExecutor(2) as executor:
                list(executor.map(self.prepare_downloaded_data, params_list)) 
        else:
            return
            
        # Concatenate the BID and ASK data
        df = pd.concat([self.new_df['0'],self.new_df['1']], axis=1)
        
        # Get the mid prices based on the BID and ASK prices
        df = taf.get_mid_series(df)
        
        # Set the hour string to resample the data
        hour_string = str(self.market_open_time.hour) if (self.market_open_time.hour)>=10 else '0'+str(self.market_open_time.hour)
        minute_string = str(self.market_open_time.minute) if (self.market_open_time.minute)>=10 else '0'+str(self.market_open_time.minute)

        # Resample the data as per the data frequency
        df = taf.resample_df(df, frequency=self.data_frequency, start=f'{hour_string}h{minute_string}min')

        # Concatenate the current historical dataframe with the whole one
        self.historical_data = pd.concat([self.historical_data, df])
        # Sor the historical data by index
        self.historical_data.sort_index(inplace=True)
        # Drop duplicates
        self.historical_data = self.historical_data[~self.historical_data.index.duplicated(keep='last')]
        
        print("Historical data was successfully prepared...")
        logging.info("Historical data was successfully prepared...")

    def tickByTickMidPoint(self, reqId, tick_time, midpoint):
        ''' Function to call in response to reqTickByTickData '''
        # Save midpoint price to last_value 
        self.last_value = midpoint
        
    def update_asset_last_value(self):
        ''' Request the update of the last value of the asset'''
        print("Updating the last value of the asset...")
        logging.info("Updating the last value of the asset...")
        # Set the last value to zero
        self.last_value = 0
        # Use the while loop in case the app has issues while requesting the last value
        while True:
            # Reques the last value of the asset price
            self.reqTickByTickData(0, self.contract, \
                                    'MidPoint', 0, True)
            time.sleep(2)
            # Cancel the request
            self.cancelTickByTickData(0)
            time.sleep(1)
            # Check if the app tried more than 50 times
            if self.last_value_count >= 50:
                print("The app couldn't get the midpoint data, it will restart...")
                logging.info("The app couldn't get the midpoint data, it will restart...")
                break
            # Check if the last value is different from zero
            if self.last_value != 0:
                print('Midpoint data obtained...')
                logging.info('Midpoint data obtained...')
                break
            # Check if the app is disconnected
            if not self.isConnected(): return
                    
            print("Couldn't get Tick midpoint data, it will try again...")
            logging.info("Couldn't get Tick midpoint data, it will try again...")
            
            # Update the last value count
            self.last_value_count += 1
                
    def updateAccountValue(self, key, value, currency, accountName):
        ''' Function to call the account values'''
        super().updateAccountValue(key, value, currency, accountName)
        # Save the data into a dictionary
        dictionary = {"key":key, "Account": accountName, "Value": value, \
                      "Currency": currency, "datetime":dt.datetime.now().replace(microsecond=0)}
                        
        # Save the data into a temporary dataframe
        self.acc_update = pd.concat([self.acc_update, pd.DataFrame(dictionary, index=[0])], ignore_index=True)
            
    def updateAccountTime(self, timeStamp: str):
        print("Account update time is:", timeStamp)
         
    def accountDownloadEnd(self, accountName: str):
        print("Account download was done for account:", accountName)
        logging.info(f"Account download was done for account: {accountName}")
        self.account_update_event.set()

    def get_capital_as_per_forex_base_currency(self, capital_datetime):
        
        # Set the yfinance data 
        usd_symbol_forex = np.nan
        usd_acc_symbol_forex = np.nan

        # If the contract symbol is the same as the account base currency
        if self.contract.symbol==self.account_currency:
            # Get the account capital value
            self.capital = self.cash_balance.loc[capital_datetime, 'value']
        else:            
            # The exchange rate where the divisor is the account base currency and the dividend is the forex pair base currency            
            exchange_rate = self.acc_update[(self.acc_update['key']=='ExchangeRate') & \
                                            (self.acc_update['Currency'] == self.contract.symbol)]['Value'].values.tolist()
                
            # If there is a exchange rate
            if len(exchange_rate)!=0:
                # Get the account capital value
                capital = self.cash_balance.loc[capital_datetime, 'value'] / float(exchange_rate[0])
            else:
                # Set the end date to download forex data from yahoo finance
                end = self.current_period + dt.timedelta(days=1)
                # Set the start date to download forex data from yahoo finance
                start = end - dt.timedelta(days=2)

                # Get the USD/contract_symbol exchange rate data
                usd_symbol_data = yf.download(f'USD{self.contract.symbol}=X', start=start, end=end, interval='1m')
                # Set the index as datetime and convert it to the app timezone
                usd_symbol_data.index = pd.to_datetime(usd_symbol_data.index).tz_convert(self.zone)
                # Get the USD/contract_symbol exchange rate most-recent value
                usd_symbol_forex = usd_symbol_data['Close'].iloc[-1]
                # Get the datetime of the most-recent exchange rate
                index = usd_symbol_data.index[-1]
            
                # Get the USD/account_currency exchange rate data
                usd_acc_symbol_data = yf.download(f'USD{self.account_currency}=X', start=start, end=end, interval='1m')
                # Set the index as datetime and convert it to the app timezone
                usd_acc_symbol_data.index = pd.to_datetime(usd_acc_symbol_data.index).tz_convert(self.zone)
                # Get the USD/account_currency exchange rate most-recent value
                usd_acc_symbol_forex = usd_acc_symbol_data.loc[index,'Close']
                
                # Get the contract_symbol / account_currency exchange rate data                
                exchange_rate = usd_symbol_forex / usd_acc_symbol_forex
                                    
                # Use the 90% of the portfolio value just in case the forex pair has changed dramatically (Yahoo Finance data is not up to date)
                capital = self.cash_balance.loc[capital_datetime, 'value'] * exchange_rate*0.9
                
        return capital      

    def update_capital(self):
        ''' Function to update the capital value'''
        print('Update the cash balance datetime and value...')
        logging.info('Update the cash balance datetime and value...')
        
        # If the app is connected
        if self.isConnected():
            # Clear the threading event
            self.account_update_event.clear()
            # Request the account update of self.account
            self.reqAccountUpdates(True,self.account)
            # Wait until the update is finished
            self.account_update_event.wait()
            # Cancel the request
            self.reqAccountUpdates(False,self.account)
            time.sleep(1)
            print('Account values successfully updated ......')
            logging.info('Account values successfully requested...')
        else:
            return
        
        # Set the cash balance datetime
        capital_datetime = \
            self.acc_update[(self.acc_update['key']=='TotalCashBalance') & \
                            (self.acc_update['Currency']=='BASE') ]['datetime'].tail(1).values[0]
                
        # Save the cash balance value
        self.cash_balance.loc[capital_datetime, 'value'] = \
            float(self.acc_update[(self.acc_update['key']=='TotalCashBalance') & \
                            (self.acc_update['Currency']=='BASE') ]['Value'].tail(1).values[0])
           
        self.capital = self.get_capital_as_per_forex_base_currency(capital_datetime)
        
        # Forward fill the cash balance dataframe
        self.cash_balance.ffill(inplace=True)
            
        print('Capital value successfully updated ...')
        logging.info('Capital value successfully updated ...')
        
    def update_risk_management_orders(self):
        ''' Function to update the risk management orders IDs and their status'''

        print('Updating the risk management orders IDs and their status...')
        logging.info('Updating the risk management orders IDs and their status...')
        
        # If the open orders dataframe is not empty
        if not self.open_orders.empty:
            # Set the last stop loss order
            self.sl_order_id = int(self.open_orders[(self.open_orders["Symbol"]==self.contract.symbol) & (self.open_orders["OrderType"]=='STP')]["OrderId"].sort_values(ascending=True).values[-1])
            # Set the last take profit order
            self.tp_order_id = int(self.open_orders[(self.open_orders["Symbol"]==self.contract.symbol) & (self.open_orders["OrderType"]=='LMT')]["OrderId"].sort_values(ascending=True).values[-1])
            
            # Set a boolean to True if the previous stop loss is filled or canceled
            self.sl_filled_or_canceled_bool = (self.open_orders[self.open_orders['OrderId'] == self.sl_order_id]['Status'].str.contains('canceled').sum()==1) or \
                                               (self.open_orders[self.open_orders['OrderId'] == self.sl_order_id]['Status'].str.contains('Filled').sum()==1) 
                
            # Set a boolean to True if the previous take profit is filled or canceled
            self.tp_filled_or_canceled_bool = (self.open_orders[self.open_orders['OrderId'] == self.tp_order_id]['Status'].str.contains('canceled').sum()==1) or \
                                               (self.open_orders[self.open_orders['OrderId'] == self.tp_order_id]['Status'].str.contains('Filled').sum()==1) 

        else:
            # Set the last stop loss order to NaN
            self.sl_order_id = np.nan
            # Set the last take profit order to NaN
            self.tp_order_id = np.nan            

            # Set a boolean to False if the previous stop loss is not filled or canceled
            self.sl_filled_or_canceled_bool = False
            # Set a boolean to False if the previous take profit is not filled or canceled
            self.tp_filled_or_canceled_bool = False
        
        print('The risk management orders IDs and their status were successfully updated...')
        logging.info('The risk management orders IDs and their status were successfully updated...')
        
    def update_remaining_position_based_on_risk_management(self, risk_management_threshold):
        ''' Function to update the remaining position and cash balance based on the selected risk management threshold'''
        
        # If the risk management selected is the stop-loss order
        if risk_management_threshold == 'sl':
            # If the previous stop loss order is filled or canceled
            if self.sl_filled_or_canceled_bool == True:
                
                # Set the remaining position value from the orders status dataframe
                remaining = float(self.orders_status[self.orders_status['OrderId'] == self.sl_order_id]['Remaining'].values[-1])
                # Set the position remaining datetime
                remaining_datetime = self.orders_status[self.orders_status['OrderId'] == self.sl_order_id].index.values[-1]
                
                # Set the average traded price from the position
                average_price = pd.to_numeric(self.exec_df[self.exec_df['OrderId'] == self.sl_order_id]['AvPrice'].values[-1])
                
                # Create a new row for the positions dataframe with the remaining datetime
                self.pos_df.loc[remaining_datetime,:] = self.pos_df[(self.pos_df['Symbol']==self.contract.symbol) & 
                                                                    (self.pos_df['Currency']==self.contract.currency)].iloc[-1,:]
                # Save the last position value in the positions dataframe
                self.pos_df.loc[remaining_datetime,'Position'] = remaining
                # Save the last average cost in the positions dataframe
                self.pos_df.loc[remaining_datetime,'Avg cost'] = average_price
                
                # Update the leverage value in the cash balance dataframe
                self.cash_balance.loc[dt.datetime.now().replace(microsecond=0), 'leverage'] = self.leverage
                # Update the signal value in the cash balance dataframe
                self.cash_balance.loc[dt.datetime.now().replace(microsecond=0), 'signal'] = 0     
                # Forward fill the cash balance dataframe
                self.cash_balance.ffill(inplace=True)
            
        # If the risk management selected is the take-profit order
        elif risk_management_threshold == 'tp':
            # If the previous take profit order is filled or canceled
            if self.tp_filled_or_canceled_bool == True:
                
                # Set the remaining position value from the orders status dataframe
                remaining = float(self.orders_status[self.orders_status['OrderId'] == self.tp_order_id]['Remaining'].values[-1])
                # Set the position remaining datetime
                remaining_datetime = self.orders_status[self.orders_status['OrderId'] == self.tp_order_id].index.values[-1]
                
                # Set the average traded price from the position
                average_price = pd.to_numeric(self.exec_df[self.exec_df['OrderId'] == self.tp_order_id]['AvPrice'].values[-1])
                
                # Create a new row for the positions dataframe with the remaining datetime
                self.pos_df.loc[remaining_datetime,:] = self.pos_df[(self.pos_df['Symbol']==self.contract.symbol) & 
                                                                    (self.pos_df['Currency']==self.contract.currency)].iloc[-1,:]
                # Save the last position value in the positions dataframe
                self.pos_df.loc[remaining_datetime,'Position'] = remaining
                # Save the last average cost in the positions dataframe
                self.pos_df.loc[remaining_datetime,'Avg cost'] = average_price
            
                # Update the leverage value in the cash balance dataframe
                self.cash_balance.loc[dt.datetime.now().replace(microsecond=0), 'leverage'] = self.leverage
                # Update the signal value in the cash balance dataframe
                self.cash_balance.loc[dt.datetime.now().replace(microsecond=0), 'signal'] = 0     
                # Forward fill the cash balance dataframe
                self.cash_balance.ffill(inplace=True)

        
    def update_submitted_orders(self):
        ''' Function to update the submitted orders'''
        
        print('Updating the submitted orders ...')
        logging.info('Updating the submitted orders ...')
        
        # If it is our first trade period of the week
        if len(self.periods_traded[self.periods_traded['trade_time']>self.market_open_time].index)==1:
            # Set the last trade period 
            last_trade_time = self.previous_period.strftime(f'%Y%m%d %H:%M:%S {self.zone}')
        # If we have already traded more than one time
        else:
            # Set the last trade period as the previous period traded
            last_trade_time = self.periods_traded[self.periods_traded.trade_done == 1]['trade_time'].iloc[-1].strftime(f'%Y%m%d %H:%M:%S {self.zone}')
        
        # If the app is connected
        if self.isConnected():
            print('Requesting executions...')
            logging.info('Requesting executions...')
            # Clear the threading event
            self.executions_request_event.clear()
            # Request the previous trading executions and commissions
            self.reqExecutions(0, taf.executionFilter(last_trade_time))
            # Make the event wait until the request is done
            self.executions_request_event.wait()
            
            print('Successfully requested execution and commissions details...')
            logging.info('Successfully requested execution and commissions details...')
        else:
            return
        
        # If the app is connected
        if self.isConnected():
            # Update the risk management orders IDs and their status
            self.update_risk_management_orders()  
        
            # If the temporal executions dataframe is not empty
            if (self.temp_exec_df.empty == False):  
                # Get rid of the time zone in the execution time column values
                self.temp_exec_df['Execution Time'] = \
                    pd.to_datetime(self.temp_exec_df['Execution Time'].replace(rf"{ self.zone}", "", regex=True).values)
                # Set the datetime as index
                self.temp_exec_df.set_index('datetime',inplace=True)
                # Erase the index name
                self.temp_exec_df.index.name = ''
                # Concatenate the temporary dataframe with the main dataframe
                self.exec_df = pd.concat([self.exec_df,self.temp_exec_df])
                # Drop duplicates
                self.exec_df.drop_duplicates(inplace=True)
                # Sort the dataframe by index
                self.exec_df.sort_index(ascending=True, inplace=True)
                # Clear the temporary dataframe
                self.temp_exec_df = pd.DataFrame()
                
                # Set the datetime as index
                self.temp_comm_df.set_index('datetime',inplace=True)
                # Erase the index name
                self.temp_comm_df.index.name = ''
                # Convert to NaN Realized PnL whose values are extremely high (due to IB mistake value)
                mask = self.temp_comm_df['Realized PnL'].astype(float) == 1.7976931348623157e+308
                self.temp_comm_df.loc[mask,'Realized PnL'] = np.nan
                # Concatenate the temporary dataframe with the main dataframe
                self.comm_df = pd.concat([self.comm_df,self.temp_comm_df])
                # Drop duplicates
                self.comm_df.drop_duplicates(inplace=True)
                # Sor the dataframe by index
                self.comm_df.sort_index(ascending=True, inplace=True)
                # Clear the temporary dataframe
                self.temp_comm_df = pd.DataFrame()

                
                # If the orders status and positions dataframes are not empty
                if (self.orders_status.empty == False) and (self.pos_df.empty == False):
                    
                    # If the previous stop-loss and take-profit target were filled or cancelled
                    if (self.sl_filled_or_canceled_bool == True) and (self.tp_filled_or_canceled_bool == True):
                        # Set the stop-loss order execution time
                        sl_order_execution_time = dt.datetime.strptime(self.exec_df[self.exec_df['OrderId'] == self.sl_order_id]['Execution Time'].values[-1], '%Y-%m-%d %H:%M:%S')
                        # Set the take-profit order execution time
                        tp_order_execution_time = dt.datetime.strptime(self.exec_df[self.exec_df['OrderId'] == self.sl_order_id]['Execution Time'].values[-1], '%Y-%m-%d %H:%M:%S')
                        
                        # If the stop-loss execution time is later than than the take-profit execution time
                        if sl_order_execution_time > tp_order_execution_time:
                            # Update the remaining position based on the previous stop-loss order
                            self.update_remaining_position_based_on_risk_management('sl')
                        else:
                            # Update the remaining position based on the previous take-profit order
                            self.update_remaining_position_based_on_risk_management('tp')
                            
                    # If the previous stop loss order is filled or canceled
                    elif self.sl_filled_or_canceled_bool == True:                    
                        # Update the remaining position based on the previous stop-loss order
                        self.update_remaining_position_based_on_risk_management('sl')
                        
                    # If the previous take profit order is filled or canceled
                    elif self.tp_filled_or_canceled_bool == True:                       
                        # Update the remaining position based on the previous take-profit order
                        self.update_remaining_position_based_on_risk_management('tp')
                        
        print('The submitted orders were successfully updated...')
        logging.info('The submitted orders were successfully updated...')
        
    def portfolio_allocation(self): 
        ''' Function to update the portfolio allocation'''

        print('Make the portfolio allocation ...')
        logging.info('Make the portfolio allocation ...')
        
        # If the app is connected
        if self.isConnected():
            # Update the capital value
            self.update_capital()            
            # Leveraged Equity
            self.capital *= self.leverage
        else:
            return

        print('Successfully Portfolio Allocation...')
        logging.info('Successfully Portfolio Allocation...')
                                                    
    def cancel_previous_stop_loss_order(self):
        ''' Function to cancel the previous stop-loss order'''

        # If there is a previous stop-loss order
        if isinstance(self.sl_order_id, int):
            # If the previous stop-loss order is not filled or canceled
            if (self.sl_filled_or_canceled_bool == False):
                # If the app is connected
                if self.isConnected():
                    # Cancel the previous stop loss order
                    self.cancelOrder(self.sl_order_id, "")
                    time.sleep(1)
                    print('Canceled old stop-loss order to create a new one...')
                    logging.info('Canceled old stop-loss order to create a new one...')
                else:
                    return

    def cancel_previous_take_profit_order(self):
        ''' Function to cancel the previous take profit order'''

        # If there is a previous take-profit order
        if isinstance(self.tp_order_id, int):
            # If the previous take-profit order is not filled or canceled
            if (self.tp_filled_or_canceled_bool == False):
                # If the app is connected
                if self.isConnected():
                    # Cancel the previous take-profit order
                    self.cancelOrder(self.tp_order_id, "")
                    time.sleep(1)
                    print('Canceled old take-profit order to create a new one...')
                    logging.info('Canceled old take-profit order to create a new one...')
                else:
                    return

    def cancel_risk_management_previous_orders(self):
        ''' Function to cancel the previous risk management orders'''
        
        print('Canceling the previous risk management orders if needed...')
        logging.info('Canceling the previous risk management orders if needed...')
                   
        # Drop the code errors related to canceling orders                                         
        self.errors_dict.pop(202, None)  
        self.errors_dict.pop(10147, None)  
        self.errors_dict.pop(10148, None)  
 
        # Create a list of executors
        executors_list = []
        # Create the executors as per each function
        with ThreadPoolExecutor(2) as executor:
            executors_list.append(executor.submit(self.cancel_previous_stop_loss_order)) 
            executors_list.append(executor.submit(self.cancel_previous_take_profit_order)) 

        # Run the executors
        for x in executors_list:
            x.result()
            
        # Drop the code errors related to canceling orders                                         
        self.errors_dict.pop(202, None)  
        self.errors_dict.pop(10147, None)  
        self.errors_dict.pop(10148, None)  
 
        print('The previous risk management orders were canceled if needed...')
        logging.info('The previous risk management orders were canceled if needed...')
                   
    def send_stop_loss_order(self, order_id, quantity): 
        ''' Function to send a stop loss order
            - The function has a while loop to incorporate the fact that sometimes
              the order is not sent due to decimal errors'''
        
        # If the previous position sign is different from the current signal
        if (self.previous_quantity!=0) and (np.sign(self.previous_quantity)==self.signal) and (self.open_orders.empty==False):
            # Set the previous stop-loss target price
            order_price = self.open_orders[self.open_orders["OrderId"]==self.sl_order_id]["AuxPrice"].values[-1]
            # Convert the quantity to an integer value
            quantity = int(abs(self.previous_quantity))
        # If they're equal
        else:
            # Set a new stop-loss target price
            order_price = sf.set_stop_loss_price(self.signal, self.last_value, self.risk_management_target, self.stop_loss_multiplier)
            # Convert the quantity to an integer value
            quantity = int(abs(quantity))
       
                
        # If the signal tells you to go long
        if self.signal > 0:
            # Set the stop-loss direction to sell the position
            direction = 'SELL'
        # If the signal tells you to short-sell the asset
        elif self.signal < 0:
            # Set the stop-loss direction to buy the position
            direction = 'BUY'
    
        # Set the add decimal to zero
        add = 0.0
        # If the add value is less than or equal to 0.0001
        while add<=0.00010:
            # Send the stop-loss order
            self.placeOrder(order_id, self.contract, taf.stopOrder(direction, quantity, order_price))
            time.sleep(3)
            # Save the output errors in data as a boolean that corresponds to any error while sending the stop-loss order
            data = (321 in list(self.errors_dict.keys())) or \
                    (110 in list(self.errors_dict.keys())) or \
                    (463 in list(self.errors_dict.keys()))
            # If data is true
            if data == True:
                # Add 0.00001 to add
                add += 0.00001
                # Set the order price to 5 decimals
                order_price = round(order_price+add,5)
                
                print("Couldn't transmit the stop-loss order, the app will try again...")
                logging.info("Couldn't transmit the-stop loss order, the app will try again...")
                
                # Clean the errors dictionary
                self.errors_dict = {}
            else:
                print(f'Stop loss sent with direction {direction}, quantity {quantity}, order price {order_price}')
                logging.info(f'Stop loss sent with direction {direction}, quantity {quantity}, order price {order_price}')
                break
            # If the app is disconnected
            if 504 in list(self.errors_dict.keys()):
                break
        
    def send_take_profit_order(self, order_id, quantity): 
        ''' Function to send a take profit order
            - The function has a while loop to incorporate the fact that sometimes
              the order is not sent due to decimal errors'''
        
        # If the previous position sign is different from the current signal
        if (self.previous_quantity!=0) and (np.sign(self.previous_quantity)==self.signal) and (self.open_orders.empty==False):
            # Set the previous take-profit target price
            order_price = self.open_orders[self.open_orders["OrderId"]==self.tp_order_id]["LmtPrice"].values[-1]
            # Convert the quantity to an integer value
            # quantity = int(abs(self.previous_quantity))
            quantity = int(abs(self.previous_quantity))
                
        # If they're equal
        else:
            # Set the take-profit target price
            order_price = sf.set_take_profit_price(self.signal, self.last_value, self.risk_management_target, self.take_profit_multiplier)
            # Convert the quantity to an integer value
            quantity = int(abs(quantity))

        # If the signal tells you to go long
        if self.signal > 0:
            # Set the take-profit direction to sell the position
            direction = 'SELL'
        # If the signal tells you to short-sell the asset
        elif self.signal < 0:
            # Set the take-profit direction to buy the position
            direction = 'BUY'
            
        # Set the add decimal to zero
        add = 0.0
        # If the add value is less than or equal to 0.0001
        while add<=0.00010:
            # Send the take-profit order
            self.placeOrder(order_id, self.contract, taf.tpOrder(direction, quantity, order_price))
            time.sleep(3)
            # Save the output errors in data as a boolean that corresponds to any error while sending the take-profit order
            data = (321 in list(self.errors_dict.keys())) or \
                    (110 in list(self.errors_dict.keys())) or \
                    (463 in list(self.errors_dict.keys()))
            # If data is true
            if data == True:
                # Add 0.00001 to add
                add += 0.00001
                # Set the order price to 5 decimals
                order_price = round(order_price-add,5)
                
                print("Couldn't transmit the take-profit order, the app will try again...")
                logging.info("Couldn't transmit the take-profit order, the app will try again...")
                
                # Clean the errors dictionary
                self.errors_dict = {}
            else:
                print(f'Take profit sent with direction {direction}, quantity {quantity}, order price {order_price}')
                logging.info(f'Take profit sent with direction {direction}, quantity {quantity}, order price {order_price}')
                break
            # If the app is disconnected
            if 504 in list(self.errors_dict.keys()):
                return
            
    def send_market_order(self, order_id, quantity):
        ''' Function to send a market order '''
        
        print('Sending the market order...')
        logging.info('Sending the market order...')
        
        # If the current period is not the last of the day
        if self.current_period != self.trading_day_end_datetime:
            # If the signal tells you to go long
            if self.signal > 0:
                # Direction will be to go long
                direction = 'BUY'
            # If the signal tells you to short-sell the asset
            elif self.signal < 0:
                # Direction will be to short-sell the asset
                direction = 'SELL'
            # If the app is connected
            if self.isConnected():
                # Place the market order
                self.placeOrder(order_id, self.contract, taf.marketOrder(direction, int(abs(quantity))))                       
                time.sleep(3)                                                
                print("Market order sent...")
                logging.info("Market order sent...")
            else:
                return
        # If the current period is the last of the day
        else:
            # If the previous quantity belongs to a long position (Close the position)
            if quantity > 0:
                # Set the direction to sell the long position
                direction = 'SELL'
            # If the previous quantity belongs to a short position
            elif quantity < 0:
                # Set the direction to buy the short position (Close the position)
                direction = 'BUY'   
            # If the app is connected
            if self.isConnected():
                # Send the market order to close the position
                self.placeOrder(order_id, self.contract, taf.marketOrder(direction, int(abs(quantity))))
                time.sleep(3)                                                
                print("Market order sent...")
                logging.info("Market order sent...")
            else:
                return
                    
    def get_previous_quantity(self):
        ''' Function to get the previous position quantity'''
        
        # If the position dataframe is not empty
        if self.pos_df.empty==False:
            # Set the previous position quantity
            self.previous_quantity = self.pos_df[(self.pos_df['Symbol']==self.contract.symbol) & \
                                                 (self.pos_df['Currency']==self.contract.currency)]["Position"].iloc[-1]
        # If it's empty
        else:
            # Set the previous position quantity to zero
            self.previous_quantity = 0
            
    def get_current_quantity(self):
        ''' Function to get the current position quantity'''
                
        self.current_quantity = int(self.capital)

    def get_previous_and_current_quantities(self):
        ''' Function to get the previous and current positions quantities'''
        
        print('Update the previous and current positions quantities...')
        logging.info('Update the previous and current positions quantities...')
        
        # If the app is connected
        if self.isConnected():
            # Update the portfolio allocation
            self.portfolio_allocation()
            # Update the last value of the asset
            self.update_asset_last_value()
        else:
            return

        # If the app is connected
        if self.isConnected():
            # Set the executors list
            executors_list = []
            # Append the functions to be multithreaded
            with ThreadPoolExecutor(2) as executor:
                executors_list.append(executor.submit(self.get_previous_quantity)) 
                executors_list.append(executor.submit(self.get_current_quantity)) 
    
            # Run the executors in parallel
            for x in executors_list:
                x.result()
        else:
            return
                
        print('The previous and current positions quantities were successfully updated...')
        logging.info('The previous and current positions quantities were successfully updated...')
        
    def update_trading_info(self):
        ''' Function to get the previous trading information'''

        print('Update the previous trading information...')
        logging.info('Update the previous trading information...')
        
        # alpha
        # # Set the executors list
        # executors_list = []
        # # Append the functions to be used in parallel
        # with ThreadPoolExecutor(3) as executor:
        #     executors_list.append(executor.submit(self.request_positions)) 
        #     executors_list.append(executor.submit(self.request_orders)) 
        #     executors_list.append(executor.submit(self.update_submitted_orders)) 

        # # Run the functions in parallel
        # for x in executors_list:
        #     x.result()
            
        self.request_positions()
        self.request_orders()
        self.update_submitted_orders()
        
    def update_cash_balance_values_for_signals(self):
        ''' Function to update the cash balance signal and leverage'''

        print('Update the cash balance signal and leverage...')
        logging.info('Update the cash balance signal and leverage...')
        
        # Update the leverage value in the cash balance dataframe
        self.cash_balance.loc[dt.datetime.now().replace(microsecond=0), 'leverage'] = self.leverage
        # Update the signal value in the cash balance dataframe
        self.cash_balance.loc[dt.datetime.now().replace(microsecond=0), 'signal'] = self.signal     
        # Forward fill the cash balance dataframe
        self.cash_balance.ffill(inplace=True)
                
        print('The cash balance signal and leverage were successfully updated...')
        logging.info('The cash balance signal and leverage were successfully updated...')
        
    def send_orders_as_bracket(self, order_id, quantity, mkt_order, sl_order, tp_order):
        ''' Function to send the orders as a bracket'''
        
        # Send a market and risk management orders
        if (mkt_order==True) and (sl_order==True) and (tp_order==True):
            self.send_market_order(order_id, quantity)
            self.send_stop_loss_order(order_id+1, quantity)
            self.send_take_profit_order(order_id+2, quantity)
        # Send only the risk management orders
        elif (mkt_order==False) and (sl_order==True) and (tp_order==True):
            self.send_stop_loss_order(order_id, quantity)
            self.send_take_profit_order(order_id+1, quantity)
        # Send only the market order
        elif (mkt_order==True) and (sl_order==False) and (tp_order==False):
            self.send_market_order(order_id, quantity)
        else:
            pass
        
    def send_orders(self):
        ''' Function to send the orders if needed'''

        print('Sending the corresponding orders if needed...')
        logging.info('Sending the corresponding orders if needed...')

        # Update the previous trading information
        self.update_trading_info()  
        # Update the previous and current positions quantities
        self.get_previous_and_current_quantities()

        # Set an initial order id
        order_id = 0
        # If the app is connected
        if self.isConnected():
            # Update the order id
            self.reqIds(-1)
            time.sleep(2)        
            # Save the new order id in order_id
            order_id = self.nextValidOrderId
        else:
            return
        
        print('='*50)
        print('='*50)
        print(f'previous quantity is {self.previous_quantity}')
        print(f'signal is {self.signal}')
        print(f'leverage is {self.leverage}')
        print(f'current quantity is {self.current_quantity}')
        print('='*50)
        print('='*50)
            
        # If the previous position is short and the current signal is to go long
        if self.previous_quantity > 0 and self.signal > 0:
            
            # Set the executors list
            executors_list = []
            # Append the functions to be used in parallel
            with ThreadPoolExecutor(2) as executor:
                # Cancel the previous risk management orders
                executors_list.append(executor.submit(self.cancel_risk_management_previous_orders))
                # Send the new risk management orders
                executors_list.append(executor.submit(self.send_orders_as_bracket, order_id, self.previous_quantity, False, True, True))

            # Run the functions in parallel
            for x in executors_list:
                x.result()
    
            print('Only the new risk management orders were sent...')
            logging.info('Only the new risk management orders were sent...')
            
        elif self.previous_quantity > 0 and self.signal < 0:
                
            new_quantity = int(abs(self.previous_quantity) + self.current_quantity)
    
            print(f'new quantity is {new_quantity}')
    
            # Set the executors list
            executors_list = []
            # Append the functions to be used in parallel
            with ThreadPoolExecutor(2) as executor:
                # Cancel the previous risk management orders
                executors_list.append(executor.submit(self.cancel_risk_management_previous_orders))
                # Short-sell the asset and send the risk management orders
                executors_list.append(executor.submit(self.send_orders_as_bracket, order_id, new_quantity, True, True, True))

            # Run the functions in parallel
            for x in executors_list:
                x.result()
                
            print('The market and the new risk management orders were sent...')
            logging.info('The market and the new risk management orders were sent...')
            
        elif self.previous_quantity < 0 and self.signal < 0:
            
            # Set the executors list
            executors_list = []
            # Append the functions to be used in parallel
            with ThreadPoolExecutor(2) as executor:
                # Cancel the previous risk management orders
                executors_list.append(executor.submit(self.cancel_risk_management_previous_orders))
                # Send the new risk management orders
                executors_list.append(executor.submit(self.send_orders_as_bracket, order_id, self.previous_quantity, False, True, True))

            # Run the functions in parallel
            for x in executors_list:
                x.result()
    
            print('Only the new risk management orders were sent...')
            logging.info('Only the new risk management orders were sent...')
            
        elif self.previous_quantity < 0 and self.signal > 0:
                        
            new_quantity = int(abs(self.previous_quantity) + self.current_quantity)
    
            print(f'new quantity is {new_quantity}')
            # Set the executors list
            executors_list = []
            # Append the functions to be used in parallel
            with ThreadPoolExecutor(2) as executor:
                # Cancel the previous risk management orders
                executors_list.append(executor.submit(self.cancel_risk_management_previous_orders))
                # Buy the asset and send the risk management orders
                executors_list.append(executor.submit(self.send_orders_as_bracket, order_id, new_quantity, True, True, True))

            # Run the functions in parallel
            for x in executors_list:
                x.result()
                
            print('The market and the new risk management orders were sent...')
            logging.info('The market and the new risk management orders were sent...')
            
        elif self.previous_quantity != 0 and self.signal == 0:
            
            # Set the executors list
            executors_list = []
            # Append the functions to be used in parallel
            with ThreadPoolExecutor(2) as executor:
                # Cancel the previous risk management orders
                executors_list.append(executor.submit(self.cancel_risk_management_previous_orders))
                # Close the previous position
                executors_list.append(executor.submit(self.send_orders_as_bracket, order_id, self.previous_quantity, True, False, False))

            # Run the functions in parallel
            for x in executors_list:
                x.result()
    
            print('A market order was sent to close the previous position...')
            logging.info('A market order was sent to close the previous position...')
            
        elif self.previous_quantity == 0 and self.signal != 0:
            
            # Set the executors list
            executors_list = []
            # Append the functions to be used in parallel
            with ThreadPoolExecutor(2) as executor:
                # Cancel the previous risk management orders
                executors_list.append(executor.submit(self.cancel_risk_management_previous_orders))
                # Buy the asset and send the risk management orders
                executors_list.append(executor.submit(self.send_orders_as_bracket, order_id, self.current_quantity, True, True, True))

            # Run the functions in parallel
            for x in executors_list:
                x.result()

            print('A new position was just opened together with new risk management orders...')
            logging.info('A new position was just opened together with new risk management orders...')
            
        # Update the signal and leverage values in the cash balance dataframe
        self.update_cash_balance_values_for_signals()
            
        # Update the trading information
        self.update_trading_info()  
                    
    def strategy(self): 
        ''' Function to get the strategy run'''
        
        print('Running the strategy for the period...')
        logging.info('Running the strategy for the period...')            
        
        # Set a default dataframe
        base_df = pd.DataFrame()
        
        # If the base_df file exists
        if os.path.exists(self.base_df_address):
            
            # Import the base_df dataframe
            base_df = pd.read_csv(self.base_df_address, index_col=0)
            # Set the index to datetime type
            base_df.index = pd.to_datetime(base_df.index)

            # If the last index value of base_df is the current period
            if base_df.index[-1] < self.current_period:
                
                # Download historical data
                self.update_hist_data()
                
                # If the app is connected
                if self.isConnected():
                    # Get the train span for the new shorter base_df
                    if self.frequency_string == 'h':
                        train_span = self.frequency_number*((self.current_period - base_df.index[-1]) + dt.timedelta(days=1)).days + 500
                    elif self.frequency_string == 'min':
                        train_span = (60//self.frequency_number)*24*((self.current_period - base_df.index[-1]) + dt.timedelta(days=1)).days + 500
    
                    # Drop index duplicates from 
                    # Create the new shorter base_df
                    base_df_to_concat, _, _ = sf.prepare_base_df(self.historical_data, self.max_window, self.test_span, train_span, self.scalable_features)
                    
                    # Concat the shorter base_df with the whole one
                    base_df = pd.concat([base_df.iloc[:-1],base_df_to_concat])  
                    
                    # Sort the base_df based on its index
                    base_df.sort_index(inplace=True)
                    # Drop duplicates
                    base_df = base_df[~base_df.index.duplicated(keep='last')]
                    # Save the base_df
                    base_df.iloc[-self.train_span:].to_csv(self.base_df_address)
                else:
                    return
                                                
        else:
            # Download historical data
            self.update_hist_data()
            
            if self.isConnected():
                # Create the new base_df
                base_df, _, _ = sf.prepare_base_df(self.historical_data, self.max_window, self.test_span, self.train_span)
                
                # Sort the base_df based on its index
                base_df.index = pd.to_datetime(base_df.index)
                # Drop duplicates
                base_df = base_df[~base_df.index.duplicated(keep='last')]
                # Save the base_df
                base_df.to_csv(self.base_df_address)
            else:
                return            
            
        # Get the signal value for the current period
        if self.isConnected():
            self.signal = sf.get_signal(self.market_open_time, base_df, self.final_input_features, self.purged_window_size, self.embargo_period, logging)
        else:
            return
                
        print('The strategy for the period was successfully run...')
        logging.info('The strategy for the period was successfully run...')
        
    def save_week_open_and_close_datetimes(self):
        """ Function to fill all the dataframes with the week's open and close datetimes"""
        
        print("Saving the corresponding week's open and close datetimes in the corresponding dataframes...")
        logging.info("Saving the corresponding week's open and close datetimes in the corresponding dataframes...")
        
        # A for loop to iterate through each of the corresponding dataframes
        for dataframe in [self.open_orders, self.orders_status, self.exec_df, self.comm_df, \
                          self.pos_df, self.cash_balance]:
            # Get the rows which correspond to the week's datetimes
            mask = (dataframe.index>=self.market_open_time) & (dataframe.index<=self.market_close_time)
            # Set the corresponding market open time in each dataframe
            dataframe.loc[mask,'market_open_time'] = self.market_open_time
            # Set the corresponding market close time in each dataframe
            dataframe.loc[mask,'market_close_time'] = self.market_close_time
            # Drop duplicates if needed based only on the columns
            dataframe = dataframe[dataframe.duplicated(subset=dataframe.columns)]
            
        # Get the rows which correspond to the week's datetimes in the periods_traded dataframe
        mask = (self.periods_traded['trade_time']>=self.market_open_time) & (self.periods_traded['trade_time']<=self.market_close_time)
        # Set the corresponding market open time in the dataframe
        self.periods_traded.loc[mask,'market_open_time'] = self.market_open_time
        # Set the corresponding market close time in the dataframe
        self.periods_traded.loc[mask,'market_close_time'] = self.market_close_time
        # Drop duplicates if needed based only on the columns
        # self.periods_traded = self.periods_traded[self.periods_traded.duplicated(subset=self.periods_traded.columns)]

        print("The corresponding week's open and close datetimes were successfully added on the dataframes...")
        logging.info("The corresponding week's open and close datetimes were successfully added on the dataframes...")
        
    def save_data(self):
        """ Function to save the data"""
        
        print("Saving all the data...")
        logging.info("Saving all the data...")
        
        # Forward-fill the cash balance dataframe values
        self.cash_balance.ffill(inplace=True)
        
        # Save the open and close market datetimes in all dataframes
        self.save_week_open_and_close_datetimes()

        # Group all the dataframes in a single dictionary
        dictfiles = {'open_orders':self.open_orders,\
                     'orders_status':self.orders_status,\
                     'executions':self.exec_df,\
                     'commissions':self.comm_df,\
                     'positions':self.pos_df,\
                     'cash_balance':self.cash_balance,\
                     'app_time_spent':self.app_time_spent,\
                     'periods_traded':self.periods_traded}
             
        # Save the dataframes in a single Excel workbook
        taf.save_xlsx(dict_df = dictfiles, path = 'trading_app_files/epat_trading_app_database.xlsx')

        # Save the historical data
        self.historical_data.to_csv(self.historical_data_address)
        
        print("All data saved...")
        logging.info("All data saved...")

    def save_data_and_send_email(self):
        """ Function to save the data and send email"""
        
        print("Saving the data and sending the email...")
        logging.info("Saving the data and sending the email...")
        
        # If the app is connected
        if self.isConnected():
            # Set the executors list
            executors_list = []
            # Append the functions to be used in parallel
            with ThreadPoolExecutor(2) as executor:
                # Save the data
                executors_list.append(executor.submit(self.save_data))
                # Send the email
                executors_list.append(executor.submit(self.send_email))
    
            # Run the functions in parallel
            for x in executors_list:
                x.result()

            print("The data was saved successfully...")
            logging.info("The data was saved successfully...")
        
    def run_strategy(self):
        """ Function to run the whole strategy, including the signal"""

        print("Running the strategy, the signal and sending the orders if necessary...")
        logging.info("Running the strategy, the signal and sending the orders if necessary...")
        
        # Run the strategy
        self.strategy()
        
        # If the app is connected
        if self.isConnected():
            # Send the orders
            self.send_orders()
            
        # Save the total seconds spent while trading in each period
        self.app_time_spent['seconds'].iloc[0] = (dt.datetime.now() - self.app_start_time).total_seconds() + 3
        
        # Set the current period as traded
        self.periods_traded['trade_done'].iloc[-1] = 1
        
        self.save_data_and_send_email()
    
        # Tell the app the strategy is done so it can be disconnected       
        self.strategy_end = True
        
        print("The strategy, the signal and sending the orders were successfully run...")
        logging.info("The strategy, the signal and sending the orders were successfully run...")
        
    def run_strategy_for_the_period(self):
        """ Function to run the whole strategy together with the connection monitor function"""

        # alpha
        # # Set the executors list
        # executors_list = []
        # # Append the functions to be used in parallel
        # with ThreadPoolExecutor(2) as executor:
        #     # Run the strategy, signal, and send orders
        #     executors_list.append(executor.submit(self.run_strategy)) 
        #     # Check the connection status throughout the entire strategy running
        #     executors_list.append(executor.submit(self.connection_monitor)) 

        # for x in executors_list:
        #     x.result()
            
        self.run_strategy()
        self.connection_monitor()
            
        # Disconnect the self
        self.stop()
        
        print("Let's wait for the next period to trade...")
        logging.info("Let's wait for the next period to trade...")

    def wait_for_next_period(self): 
        """ Function to wait for the next period"""
        
        print("Let's wait for the next period to trade...")
        logging.info("Let's wait for the next period to trade...")
        
        # Disconnect the self
        self.stop()
                    
        # Wait until we arrive at the next trading period
        time.sleep(0 if (self.next_period-dt.datetime.now()).total_seconds()<0 else (self.next_period-dt.datetime.now()).total_seconds())

    def update_and_close_positions(self):
        """ Function to update and close the current position before the day closes"""

        print('Update the trading info and closing the position...')
        logging.info('Update the trading info and closing the position...')
        
        # Update the trading info        
        self.update_trading_info()  
        
        # Cancel the previous risk management orders
        self.cancel_risk_management_previous_orders()                        

        # Signal and leverage are zero at the end of the day
        self.signal = self.leverage = 0
        
        # Get the previous and current quantities
        self.get_previous_and_current_quantities()
        
        # If the app is connected
        if self.isConnected():
            # Update the order id
            self.reqIds(-1)
            time.sleep(2)        
            order_id = self.nextValidOrderId
        
        # If the app is connected
        if self.isConnected():
            # If a position exists
            if self.previous_quantity != 0.0:
                # Send a market order
                self.send_market_order(order_id, self.previous_quantity) 
        
        # Update the signal and leverage values in the cash balance dataframe
        self.update_cash_balance_values_for_signals()
        
        # If the app is connected
        if self.isConnected():
            # Update the trading info
            self.update_trading_info()  
        
        # Update the current equity value
        self.update_capital()
        
        # Update the current period trading status
        self.periods_traded['trade_done'].iloc[-1] = 1

        # Save the data and send the email
        self.save_data_and_send_email()
        
        print('The trading info was updated and the position was closed successfully...')
        logging.info('The trading info was updated and the position was closed successfully...')
        
        if (self.next_period != self.market_close_time):
            print("Let's wait for the next trading day to start...")
            logging.info("Let's wait the next trading day to start...")
        else:
            print("Let's wait for the market to get closed...")
            logging.info("Let's wait for the market to get closed...")
            
        # Disconnect the app
        self.stop()
        
        # Wait until we arrive at the next trading period
        time.sleep(0 if (self.next_period-dt.datetime.now()).total_seconds()<0 else (self.next_period-dt.datetime.now()).total_seconds())


    def send_email(self): 
        """ Function to send an email with relevant information of the trading current period"""

        if (self.open_orders.empty==False) and (self.orders_status.empty==False):
            
            try:
                # Get the market id 
                mkt_order_id = int(self.open_orders[(self.open_orders["Symbol"]==self.contract.symbol) & (self.open_orders["OrderType"]=='MKT')]["OrderId"].sort_values(ascending=True).values[-1])
                # Get the stop loss id 
                sl_order_id = int(self.open_orders[(self.open_orders["Symbol"]==self.contract.symbol) & (self.open_orders["OrderType"]=='STP')]["OrderId"].sort_values(ascending=True).values[-1])
                # Get the take profit id 
                tp_order_id = int(self.open_orders[(self.open_orders["Symbol"]==self.contract.symbol) & (self.open_orders["OrderType"]=='LMT')]["OrderId"].sort_values(ascending=True).values[-1])
                
                # Get the market order price
                market_order_price = float(self.orders_status[(self.orders_status['OrderId'] == mkt_order_id) & (self.orders_status['Status'] == 'Filled')]['AvgFillPrice'].sort_values(ascending=True).values[-1])
                # Get the stop loss price
                sl_order_price = float(self.open_orders[self.open_orders['OrderId'] == sl_order_id]['AuxPrice'].sort_values(ascending=True).values[-1])
                # Get the take profit price
                tp_order_price = float(self.open_orders[self.open_orders['OrderId'] == tp_order_id]['LmtPrice'].sort_values(ascending=True).values[-1])
                     
                # Import the email dataframe
                email_password = pd.read_excel('trading_app_files/email_info.xlsx', index_col = 0)
                
                # Set the Gmail server
                smtp_server = 'smtp.gmail.com'
                # Set the Gmail port
                smtp_port = 587
                # Set the trader's email
                smtp_username = email_password['smtp_username'].iloc[0]
                # Set the trader's email password
                smtp_password = email_password['password'].iloc[0]
                
                # Set the trader's email to send the email
                from_email = email_password['smtp_username'].iloc[0]
                # Set the email to which we'll send the current period trading information
                to_email = email_password['to_email'].iloc[0]
                    
                # Email subject
                subject = 'EPAT Trading App Status'
                # Body of the email per line
                body0 = f'- The period {self.current_period} was successfully traded'
                body1 = f'- The Forex pair is {self.ticker}'
                body2 = f'- The signal is {self.signal}'
                body3 = f'- The leverage is {self.leverage}'
                body4 = f"- The cash balance value is {round(self.cash_balance['value'].values[-1],2)} {self.account_currency}"
                body5 = f'- The current position quantity is {self.current_quantity} {self.contract.symbol}'
                body6 = f'- The stop-loss price is {sl_order_price}'
                body7 = f'- The market price is {market_order_price}'
                body8 = f'- The take-profit price is {tp_order_price}'
                
                # Concatenate the email message
                message = f'Subject: {subject}\n\n{body0}\n\n{body1}\n{body2}\n{body3}\n{body4}\n{body5}\n{body6}\n{body7}\n{body8}'
                
                # Send the email
                with smtplib.SMTP(smtp_server, smtp_port) as smtp:
                    smtp.starttls()
                    smtp.login(smtp_username, smtp_password)
                    smtp.sendmail(from_email, to_email, message)
                    
                print("The email was sent successfully...")
                logging.info("The email was sent successfully...")
        
            except:
                # Email subject
                subject = 'EPAT Trading app Status'
                # Body of the email per line
                body0 = f'- The period {self.current_period} was successfully traded'
                
                # Concatenate the email message
                message = f'Subject: {subject}\n\n{body0}'
                
                print("The email was sent successfully...")
                logging.info("The email was sent successfully...")
         
    # Disconnect the app
    def stop(self):
        print('Disconnecting...')
        self.disconnect()

# -------------------------x-----------------------x--------------------------#
# -------------------------x-----------------------x--------------------------#
# -------------------------x-----------------------x--------------------------#
   
# Function to run the app each period
def run_app(host, port, account, client_id, timezone, now_, account_currency, symbol, leverage, risk_management_target, stop_loss_multiplier, take_profit_multiplier, 
            historical_data_address, base_df_address, data_frequency, purged_window_size, embargo_period, 
            trading_day_end_datetime, day_end_datetime, previous_day_start_datetime, day_start_datetime, market_open_time, market_close_time, train_span, test_span, max_window):
    
    print('='*100)
    print('='*100)
    logging.info('='*100)
    logging.info('='*100)

    print('Running the app...wish you the best!')
    logging.info('Running the app...wish you the best!')

    # Get the previous, current and next trading periods
    previous_period, current_period, next_period = taf.get_the_closest_periods(dt.datetime.now(), data_frequency, trading_day_end_datetime, previous_day_start_datetime, day_start_datetime, market_close_time)
    
    # A while loop to run the app, we will break the loop whenever we finish running the app for the current period
    while True:
        # Create an object of the app class
        app = trading_app(account, account_currency, symbol, timezone, data_frequency, historical_data_address, base_df_address, leverage, 
                          risk_management_target, stop_loss_multiplier, take_profit_multiplier, purged_window_size, embargo_period, market_open_time, market_close_time, 
                          previous_day_start_datetime, trading_day_end_datetime, day_end_datetime, current_period, previous_period, next_period, train_span, test_span, max_window)
                
        # Connect the app to the IB server
        print('Connecting the app to the IB server...')
        logging.info('Connecting the app to the IB server...')
        app.connect(host=host, port=port, clientId=client_id)
        
        # Set the app thread as the main one
        thread1 = Thread(target=app.run, daemon=True)
    
        # Start the app
        thread1.start()
            
        # Wait until the app is successfully connected
        time.sleep(5)
        
        print('='*100)
        print(f'Current period is {current_period}')
        logging.info(f'Current period is {current_period}')
        print(f'Trading day end datetime is {trading_day_end_datetime}')
        logging.info(f'Trading day end datetime is {trading_day_end_datetime}')
        print('='*100)
        
        # If now is before the market close datetime
        if dt.datetime.now() < market_close_time:
    
            # If now is before the trading day end datetime
            if dt.datetime.now() < trading_day_end_datetime:
                
                # If the current period hasn't been traded
                if app.periods_traded.loc[app.periods_traded['trade_time']==current_period]['trade_done'].values[0] == 0:
                    
                    # If the strategy time spent is filled
                    if app.previous_time_spent > 0:
                        if app.previous_time_spent >= (next_period - current_period).total_seconds():
                            app.previous_time_spent = 60
                        # If the previous time spent is less than the seconds left until the next trading period
                        if app.previous_time_spent < (next_period - dt.datetime.now()).total_seconds():
                            # Run the strategy, create the signal, and send orders if necessary
                            app.run_strategy_for_the_period()
                            # If the strategy was successfully done
                            if app.strategy_end:
                                # Wait until we arrive at the next trading period
                                time.sleep(0 if (next_period-dt.datetime.now()).total_seconds()<0 else (next_period-dt.datetime.now()).total_seconds())
                                break
                            else:
                                # Couldn't connect to IB server, we'll try once again
                                print("Couldn't connect to the IB server, could be due to internet issues or the TWS/IB Gateway is not opened...")
                                logging.info("Couldn't connect to the IB server, could be due to internet issues or the TWS/IB Gateway is not opened...")
                        else:
                            print("Time up to the next period is not sufficient to run the strategy for the current period...")
                            logging.info("Time up to the next period is not sufficient to run the strategy for the current period...")
                            # Wait until we arrive at the next trading period
                            app.wait_for_next_period()
                            time.sleep(0 if (next_period-dt.datetime.now()).total_seconds()<0 else (next_period-dt.datetime.now()).total_seconds())
                            break
                      
                    # If the strategy time spent is not fille, i.e., it's the first time we trade
                    else:
                        # Run the strategy, create the signal, and send orders if necessary
                        app.run_strategy_for_the_period()
                        # If the strategy was successfully done
                        if app.strategy_end:
                            # Wait until we arrive at the next trading period
                            time.sleep(0 if (next_period-dt.datetime.now()).total_seconds()<0 else (next_period-dt.datetime.now()).total_seconds())
                            break
                        else:
                            # Couldn't connect to IB server, we'll try once again
                            print("Couldn't connect to the IB server, could be due to internet issues or the TWS/IB Gateway is not opened...")
                            logging.info("Couldn't connect to the IB server, could be due to internet issues or the TWS/IB Gateway is not opened...")
                
                # If the current period has already been traded
                else:
                    print("The current period has already been traded. Let's wait for the next period...")
                    logging.info("The current period has already been traded. Let's wait for the next period...")
                    # Wait until we arrive at the next trading period
                    app.wait_for_next_period()
                    break
            # If now is after the trading day end datetime
            else:
                print("The trading end datetime has arrived. Let's close the existing position if exists and update the trading info...")
                logging.info("The trading end datetime has arrived. Let's close the existing position if exists and update the trading info...")
                # If the current period hasn't been traded
                if app.periods_traded.loc[app.periods_traded['trade_time']==trading_day_end_datetime]['trade_done'].values[0] == 0:
                    # Update the trading information and close the position if needed before the market closes
                    app.update_and_close_positions()
                else:
                    print("The last position was already closed and the trading info was already updated...")
                    logging.info("The last position was already closed and the trading info was already updated...")
                    
                # Wait until we arrive at the next trading period
                print("Let's wait until the new trading day begins...")
                logging.info("Let's wait until the new trading day begins...")
                time.sleep(0 if (day_start_datetime-dt.datetime.now()).total_seconds()<0 else (day_start_datetime-dt.datetime.now()).total_seconds())
                break
        # If now is after the market close datetime
        else:   
            print('The market has closed...')       
            logging.info('The market has closed...')       
            break
                
# Run the trading all inside a loop for the whole week                        
def run_trading_app_loop(host, port, account, client_id, data_frequency, london_start_hour, local_restart_hour, timezone, now_, account_currency, symbol, leverage, risk_management_target, stop_loss_multiplier, take_profit_multiplier, 
                         historical_data_address, base_df_address, purged_window_size, embargo_period, train_span, test_span, max_window):  
                  
    print('='*100)
    print('='*100)
    print('='*100)
    logging.info('='*100)
    logging.info('='*100)
    logging.info('='*100)

    # Get the local timezone hours that match the Easter timezone hours
    restart_hour, restart_minute, day_end_hour, day_end_minute, trading_start_hour = taf.get_end_hours(timezone, london_start_hour, local_restart_hour)
    # Get the market open and close datetimes of the current week
    market_open_time, market_close_time = taf.define_trading_week(timezone, trading_start_hour, day_end_minute)
    
    # Get the corresponding auto-restart and day-end datetimes to be used while trading
    auto_restart_start_datetime, auto_restart_datetime_before_end, auto_restart_end_datetime, \
        day_start_datetime, day_datetime_before_end, trading_day_end_datetime, day_end_datetime, previous_day_start_datetime = \
            taf.get_restart_and_day_close_datetimes(data_frequency, dt.datetime.now(), day_end_hour, day_end_minute, restart_hour, restart_minute, trading_start_hour)

    print(f'market open time is {market_open_time}')
    logging.info(f'market open time is {market_open_time}')
    print(f'market close time is {market_close_time}')
    logging.info(f'market close time is {market_close_time}')
    
    print(f'\t - auto_restart_start_datetime is {auto_restart_start_datetime}')
    print(f'\t - auto_restart_datetime_before_end is {auto_restart_datetime_before_end}')
    print(f'\t - auto_restart_end_datetime is {auto_restart_end_datetime}')
    if dt.datetime.now()>=market_open_time:
       print(f'\t - previous_day_start_datetime is {previous_day_start_datetime}')
    print(f'\t - day_datetime_before_end is {day_datetime_before_end}')
    print(f'\t - trading_day_end_datetime is {trading_day_end_datetime}')
    print(f'\t - day_end_datetime is {day_end_datetime}')
    print(f'\t - day_start_datetime is {day_start_datetime}')

    # Check if now is sooner than the market opening datetime
    if dt.datetime.now() < market_open_time:
        print("Let's wait until the market opens...")
        logging.info("Let's wait until the market opens...")
        # If we are outside the week's market hours, we wait until we're in
        while dt.datetime.now() <= market_open_time: continue
    
    # Check if now is sooner than the day start datetime
    if dt.datetime.now() < previous_day_start_datetime:
        print("Let's wait until the trading day starts...")
        logging.info("Let's wait until the trading day starts...")
        # Start trading at the trading start datetime
        while dt.datetime.now() <= previous_day_start_datetime: continue
        
    # If we're inside the week's market hours
    while dt.datetime.now() >= market_open_time and dt.datetime.now() <= market_close_time:
        # Get the local timezone hours that match the Easter timezone hours
        restart_hour, restart_minute, day_end_hour, day_end_minute, trading_start_hour = taf.get_end_hours(timezone, london_start_hour, local_restart_hour)
        
        # Get the corresponding autorestart and day-end datetimes to be used while trading
        auto_restart_start_datetime, auto_restart_datetime_before_end, auto_restart_end_datetime, \
            day_start_datetime, day_datetime_before_end, trading_day_end_datetime, day_end_datetime, previous_day_start_datetime = \
                taf.get_restart_and_day_close_datetimes(data_frequency, dt.datetime.now(), day_end_hour, day_end_minute, restart_hour, restart_minute, trading_start_hour)
                
        # Set the highest hour
        highest_hour = restart_hour if restart_hour > day_end_hour else day_end_hour
        
        # Set the highest minute
        highest_minute = auto_restart_datetime_before_end.minute if highest_hour == restart_hour else day_end_datetime.minute
    
        # If now is sooner than the last day and the auto-restart hour
        if ((dt.datetime.now().weekday() <= (market_close_time.weekday()-1)) and (dt.datetime.now().hour < highest_hour) \
            and (dt.datetime.now().minute < highest_minute)): 
            
            # If the auto-restart datetime is sooner than the day start datetime
            if auto_restart_datetime_before_end < day_start_datetime:
                # A while loop to run the app
                while True:
                    # If now is less than the autorestart datetime
                    if (dt.datetime.now() < auto_restart_datetime_before_end):
                        # Run the app
                        run_app(host, port, account, client_id, timezone, now_, account_currency, symbol, leverage, risk_management_target, stop_loss_multiplier, take_profit_multiplier, historical_data_address, base_df_address, data_frequency, purged_window_size, embargo_period, 
                                    trading_day_end_datetime, day_end_datetime, previous_day_start_datetime, day_start_datetime, market_open_time, market_close_time, train_span, test_span, max_window)
                    # If now is higher than the auto-restart datetime
                    else:
                        # Break the while loop
                        break
                # Wait until now is higher than auto-restart start datetime
                while (dt.datetime.now() >= auto_restart_datetime_before_end) and (dt.datetime.now() < auto_restart_start_datetime): continue
            # If the autorestart datetime is later than the day start datetime
            else:
                # A while loop to run the app
                while True:                
                    # If now is sooner than the day datetime before the day closes
                    if (dt.datetime.now() < day_datetime_before_end):
                        # Run the app
                        run_app(host, port, account, client_id, timezone, now_, account_currency, symbol, leverage, risk_management_target, stop_loss_multiplier, take_profit_multiplier, historical_data_address, base_df_address, data_frequency, purged_window_size, embargo_period, 
                                    trading_day_end_datetime, day_end_datetime, previous_day_start_datetime, day_start_datetime, market_open_time, market_close_time, train_span, test_span, max_window)
                    # If now is later than the day datetime before the day closes
                    else:
                        # Break the while loop
                        break
                        
                # A while loop to run the app
                while True:                
                    # If now is later than the day datetime before the day closes and sooner than the trading day end datetime
                    if (dt.datetime.now() >= day_datetime_before_end) and (dt.datetime.now() < trading_day_end_datetime):
                        # Run the app
                        run_app(host, port, account, client_id, timezone, now_, account_currency, symbol, leverage, risk_management_target, stop_loss_multiplier, take_profit_multiplier, historical_data_address, base_df_address, data_frequency, purged_window_size, embargo_period, 
                                    trading_day_end_datetime, day_end_datetime, previous_day_start_datetime, day_start_datetime, market_open_time, market_close_time, train_span, test_span, max_window)
                    # If now is later than the trading day end datetime
                    else:
                        # Break the while loop
                        break
                # A while loop to run the app
                while True:                
                    # If now is later than the trading day end datetime and sooner than the day end datetime
                    if (dt.datetime.now() >= trading_day_end_datetime) and (dt.datetime.now() < day_end_datetime):
                        # Run the app
                        run_app(host, port, account, client_id, timezone, now_, account_currency, symbol, leverage, risk_management_target, stop_loss_multiplier, take_profit_multiplier, historical_data_address, base_df_address, data_frequency, purged_window_size, embargo_period, 
                                    trading_day_end_datetime, day_end_datetime, previous_day_start_datetime, day_start_datetime, market_open_time, market_close_time, train_span, test_span, max_window)
                    # If now is later than the day-end datetime
                    else:
                        # Break the while loop
                        break
                                        
                print("Let's wait until we start the trading day once again")
                logging.info("Let's wait until we start the trading day once again")
                while (dt.datetime.now() >= day_end_datetime) and (dt.datetime.now() < day_start_datetime): continue
            
        # If now is last day and later than the auto-restart hour                                                                                
        else:
            
            # A while loop to run the app
            while True:                
                # If now is sooner than the day datetime before the day closes
                if (dt.datetime.now() <= day_datetime_before_end):
                    # Run the app
                    run_app(host, port, account, client_id, timezone, now_, account_currency, symbol, leverage, risk_management_target, stop_loss_multiplier, take_profit_multiplier, historical_data_address, base_df_address, data_frequency, purged_window_size, embargo_period, 
                            trading_day_end_datetime, day_end_datetime, previous_day_start_datetime, day_start_datetime, market_open_time, market_close_time, train_span, test_span, max_window)
                # If now is later than the day datetime before the day closes
                else:
                    # Break the while loop
                    break
            # A while loop to run the app
            while True:                
                # If now is later than the day datetime before the day closes and sooner than the trading day end datetime
                if (dt.datetime.now() >= day_datetime_before_end) and (dt.datetime.now() < trading_day_end_datetime): 
                    # Run the app
                    run_app(host, port, account, client_id, timezone, now_, account_currency, symbol, leverage, risk_management_target, stop_loss_multiplier, take_profit_multiplier, historical_data_address, base_df_address, data_frequency, purged_window_size, embargo_period, 
                            trading_day_end_datetime, day_end_datetime, previous_day_start_datetime, day_start_datetime, market_open_time, market_close_time, train_span, test_span, max_window)
                # If now is later than the trading day end datetime
                else:
                    # Break the while loop
                    break
            # A while loop to run the app
            while True:                
                # If now is later than the trading day end datetime and sooner than the day end datetime
                if (dt.datetime.now() >= trading_day_end_datetime) and (dt.datetime.now() < day_end_datetime):
                    # Run the app
                    run_app(host, port, account, client_id, timezone, now_, account_currency, symbol, leverage, risk_management_target, stop_loss_multiplier, take_profit_multiplier, historical_data_address, base_df_address, data_frequency, purged_window_size, embargo_period, 
                            trading_day_end_datetime, day_end_datetime, previous_day_start_datetime, day_start_datetime, market_open_time, market_close_time, train_span, test_span, max_window)
                # If now is later than the day-end datetime
                else:
                    # Break the while loop
                    break
                                        
            print("Let's wait until the trading week close datetime arrives")
            logging.info("Let's wait until the trading week close datetime arrives")
            while (dt.datetime.now() >= day_end_datetime) and (dt.datetime.now() < day_start_datetime): continue
    
# A main function to run everything
def main(account, timezone, port, account_currency, symbol, data_frequency, local_restart_hour, historical_data_address, base_df_address, train_span, test_span_days, 
         max_window, host, client_id, purged_window_size, embargo_period, seed, random_seeds, leverage, risk_management_target, stop_loss_multiplier, take_profit_multiplier, smtp_username, to_email, password):   
     
    # Set the London-timezone hour as the trading start hour
    london_start_hour = 23
    
    # The historical minute-frequency data address
    historical_minute_data_address = f'trading_app_files/app_{symbol}_df.csv'
        
    # Set the test span
    test_span = test_span_days*taf.get_periods_per_day(data_frequency)
    
    # Add the test span value to the train span
    train_span += test_span
    
    # Get the local timezone hours that match the Easter timezone hours
    restart_hour, restart_minute, day_end_hour, day_end_minute, trading_start_hour = taf.get_end_hours(timezone, london_start_hour, local_restart_hour)
    
    # Get the market open and close datetimes of the current week
    market_open_time, market_close_time = taf.define_trading_week(timezone, trading_start_hour, day_end_minute)
    
    month_string = str(market_open_time.month) if market_open_time.month>=10 else '0'+str(market_open_time.month)
    day_string = str(market_open_time.day-1) if (market_open_time.day-1)>=10 else '0'+str(market_open_time.day-1)

    # If you don't have historical minute-frequency data
    if os.path.exists(historical_minute_data_address)==False:
        print('='*100)
        print('='*100)
        print('='*100)
        print('Creating the whole historical minute-frequency data...')
        tadd.run_hist_data_download_app(historical_minute_data_address, historical_data_address, symbol, timezone, data_frequency, 'false', '10 D', train_span, market_open_time)
        print('='*100)
        print('='*100)
        print('='*100)
        print('Optimizating the strategy parameters...')
        # Optimize the strategy parameters
        sf.strategy_parameter_optimization(market_open_time, seed, random_seeds, data_frequency, max_window, historical_minute_data_address, train_span, test_span)
    # If you do have a historical minute-frequency data
    else:
        # Update the historical minute-frequency and the resampled data
        tadd.run_hist_data_download_app(historical_minute_data_address, historical_data_address, symbol, timezone, data_frequency, 'true', '10 D', train_span, market_open_time)

        # If it's the first time you begin to go live trading
        if (os.path.exists(f'trading_app_files/model_object_{market_open_time.year}_{month_string}_{day_string}.pickle')==False):
            print('='*100)
            print('='*100)
            print('='*100)
            print('Optimizating the strategy parameters...')
            # Optimize the strategy parameters
            sf.strategy_parameter_optimization(market_open_time, seed, random_seeds, data_frequency, max_window, historical_minute_data_address, base_df_address, purged_window_size, embargo_period, train_span, test_span)
        
    if os.path.exists("trading_app_files/epat_trading_app_database.xlsx")==False:
        print('='*100)
        print('='*100)
        print('='*100)
        print('Creating the trading information database...')
        # Create the Excel workbook to save the trading information
        tacd.create_trading_info_workbook(smtp_username, to_email , password)
        
    print('='*100)
    print('='*100)
    print('='*100)
    print('Running the trading app for the week...')
    # Run the app loop
    run_trading_app_loop(host, port, account, client_id, data_frequency, london_start_hour, local_restart_hour, timezone, dt.datetime.now(), account_currency, symbol, leverage, risk_management_target, stop_loss_multiplier, take_profit_multiplier, 
                         historical_data_address, base_df_address, purged_window_size, embargo_period, train_span, 1, max_window)
        
    print('='*100)
    print('='*100)
    print('='*100)
    print('Updating the minute-frequency and resampled data...')
    # Update the historical minute-frequency and the resampled data
    tadd.run_hist_data_download_app(historical_minute_data_address, historical_data_address, symbol, timezone, data_frequency, 'true', '10 D', train_span, market_open_time)
    
    # Get the local timezone hours that match the Easter timezone hours
    restart_hour, restart_minute, day_end_hour, day_end_minute, trading_start_hour = taf.get_end_hours(timezone, london_start_hour, local_restart_hour)
    
    # Get the market open and close datetimes of the current week
    market_open_time, market_close_time = taf.define_trading_week(timezone, trading_start_hour, day_end_minute)

    # Set the month and day strings to call the models
    month_string = str(market_open_time.month) if market_open_time.month>=10 else '0'+str(market_open_time.month)
    day_string = str(market_open_time.day-1) if (market_open_time.day-1)>=10 else '0'+str(market_open_time.day-1)

    if (os.path.exists(f'trading_app_files/model_object_{market_open_time.year}_{month_string}_{day_string}.pickle')==False):
        print('='*100)
        print('='*100)
        print('='*100)
        print('Optimizating the strategy parameters...')

        # Optimize the strategy parameters once the market closes
        sf.strategy_parameter_optimization(market_open_time, seed, random_seeds, data_frequency, max_window, historical_minute_data_address, base_df_address, purged_window_size, embargo_period, train_span, test_span)

                